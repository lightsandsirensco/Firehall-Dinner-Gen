import { z } from "zod";

export const generateRequestSchema = z.object({
  crew_size: z.number().min(2).max(20),
  busy_level: z.enum(["quiet", "average", "busy", "slammed"]),
  time_available: z.enum(["15-25", "20-30", "25-40", "30-45", "45-60", "60-90"]),
  appliances: z.array(z.string()).min(1),
  proteins: z.array(z.string()).min(1),
  healthiness_preference: z.enum(["lean", "balanced", "comfort"]),
  budget_level: z.enum(["low", "standard", "splurge"]).optional().default("standard"),
  allergens_to_avoid: z.array(z.string()),
  vegetarian_swap_needed: z.boolean().optional().default(false),
  last_template_id: z.number().optional(),
  use_what_we_have: z.boolean().optional().default(false),
  ingredients_on_hand: z.array(z.string()).optional().default([]),
});

export type GenerateRequest = z.infer<typeof generateRequestSchema>;

export interface IngredientItem {
  item: string;
  amount: string;
  notes: string;
}

export interface MacrosPerServing {
  calories: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
}

export interface RecipeTiming {
  prep_minutes: number;
  cook_minutes: number;
  total_minutes: number;
}

export interface ProteinSafetyItem {
  protein: string;
  target_temp_f: number;
  target_temp_c: number;
  rest_minutes: number;
  probe_where: string;
  notes: string;
}

export interface RecipeStep {
  heading: string;
  body: string;
}

export interface VegOptionIngredient {
  item: string;
  amount: string;
  notes: string;
}

export interface VegOption {
  enabled: boolean;
  swap_protein: string;
  ingredients: VegOptionIngredient[];
  steps: string[];
  plating_notes: string;
}

export interface GenerateResponse {
  template_id: number;
  chosen_protein: string;
  title: string;
  why_it_fits_tonight: string;
  timing: RecipeTiming;
  protein_safety: ProteinSafetyItem[];
  ingredients: IngredientItem[];
  steps: RecipeStep[];
  cleanup_tip: string;
  macros_per_serving: MacrosPerServing;
  veg_option?: VegOption;
  ingredients_used?: string[];
  extra_items_needed?: string[];
  budget_level?: string;
  budget_tips?: string[];
}

export const pizzaRequestSchema = z.object({
  crew_size: z.number().min(2).max(20),
  time_available: z.enum(["30-45", "45-60", "60-90", "90-150"]),
  dough_option: z.enum(["premade", "from_scratch", "surprise_me"]),
  style_preference: z.enum(["classic", "creative", "comfort", "healthier"]),
  heat_level: z.enum(["mild", "medium", "spicy"]),
  allergens_to_avoid: z.array(z.string()),
  vegetarian_swap_needed: z.boolean().optional().default(false),
  last_pizza_style_id: z.string().optional(),
});

export type PizzaRequest = z.infer<typeof pizzaRequestSchema>;

export interface PizzaOvenSetup {
  preheat_temp_f: number;
  preheat_temp_c: number;
  rack_position: string;
  surface_option: string;
}

export interface PizzaTiming {
  prep_minutes: number;
  bake_minutes: number;
  total_minutes: number;
}

export interface PizzaResponse {
  pizza_style_id: string;
  title: string;
  dough_type: string;
  why_this_works: string;
  recommended_pizzas: string;
  timing: PizzaTiming;
  oven_setup: PizzaOvenSetup;
  ingredients: {
    dough?: IngredientItem[];
    sauce: IngredientItem[];
    cheese: IngredientItem[];
    toppings: IngredientItem[];
    drizzles: IngredientItem[];
  };
  build_steps: RecipeStep[];
  protein_safety: ProteinSafetyItem[];
  veg_option?: {
    enabled: boolean;
    description: string;
    swap_toppings: IngredientItem[];
    steps: string[];
  };
  cleanup_tip: string;
  macros_per_serving: MacrosPerServing;
}

export interface TemplateRow {
  template_id: string;
  template_name: string;
  style: string;
  base_idea_description: string;
  appliances_needed: string;
  time_range_minutes: string;
  busy_level_fit: string;
  healthiness_level: string;
  proteins_allowed: string;
  allergens_possible: string;
  mess_level: string;
  reheat_friendly: string;
}
